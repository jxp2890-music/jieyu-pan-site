Jieyu Pan — Static Portfolio (粉绿风)
----------------------------------
Files:
- index.html  -> main page
- style.css   -> styling (粉绿生机风)
- script.js   -> bilingual toggle + background music control
- media/bg-music.mp3 -> placeholder for background music (replace with your mp3)
- images/     -> add photos if needed

How to publish quickly (GitHub Pages):
1. Create a new GitHub repository.
2. Upload all files (use "Add file" -> "Upload files").
3. In repository Settings -> Pages, choose branch "main" and folder "/" then Save.
4. Your site will be published at https://<your-username>.github.io/<repo-name> within a minute.

Or deploy to Vercel:
1. Create a new Project -> Import -> Upload -> choose this zip file
2. Deploy. Vercel will host the static site.

Replace media/bg-music.mp3 with your preferred loop (keep it short and not copyrighted).
